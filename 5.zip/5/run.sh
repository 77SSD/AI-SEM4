#!/bin/bash

python3 TSP.py $1