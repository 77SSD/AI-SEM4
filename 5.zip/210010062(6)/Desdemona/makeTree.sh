cd bots/AlphaBetaBot
make clean
make all
cd ../..
./bin/Desdemona ./bots/AlphaBetaBot/bot.so ./bots/RandomBot/RandomBot.so