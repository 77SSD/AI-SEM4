HOW TO RUN THE CODE :

*After extracting these files, 
 open bash in the same directory folder that these files are in.

*This program was created in python3, hence the bash shell file is coded as such.

*Type into bash terminal: bash run.sh <file-name> , where <file-name> is the name of the input file, e.g. euc_100

*The program is set to stop after 250 seconds from the start OR after 600 iterations of ACO.

*The output will be displayed in the bash terminal itself.

*Preferably, wait until the execution is complete, i.e. 250s or 600 iterations.

*However, in case the value of cost has seemingly stabilized at some value for an extended num of runs, it is okay to consider it.