#!/bin/bash

python3 5.py $1