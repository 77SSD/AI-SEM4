INPUT : Read from file input.txt

INPUT FORMAT :
-> First three lines represent the three stacks of Start node.
-> The starting element of every line is the block placed on the ground.
-> A blank line to separate the Start node from Goal node.
-> Next three lines represent the three stacks of Goal node.
-> Any blank line in first three lines or last three lines implies the stack is empty.

OUTPUT : Written in file output.txt